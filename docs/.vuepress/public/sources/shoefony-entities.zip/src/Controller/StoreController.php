<?php

namespace App\Controller;

use App\Repository\Store\ProductRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/store", name="store_")
 */
class StoreController extends AbstractController
{
    private $productRepository;

    public function __construct(ProductRepository $productRepository)
    {
        $this->productRepository = $productRepository;
    }

    /**
     * @Route("/products", name="products")
     */
    public function products()
    {
        return $this->render('store/products.html.twig', [
            'products' => $this->productRepository->findAll()
        ]);
    }

    /**
     * @Route("/product/{id}/details/{slug}", name="product", requirements={"id" = "\d+"})
     */
    public function product(int $id, string $slug)
    {
        return $this->render('store/product.html.twig');
    }
}
