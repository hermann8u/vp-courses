<?php

namespace App\Controller;

use App\Repository\Store\ProductRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/store", name="store_")
 */
class StoreController extends AbstractController
{
    /** @var ProductRepository */
    private $productRepository;

    public function __construct(ProductRepository $productRepository)
    {
        $this->productRepository = $productRepository;
    }
    /**
     * @Route("", name="list")
     */
    public function list(): Response
    {
        return $this->render('store/list.html.twig', [
            'products' => $this->productRepository->findAll(),
        ]);
    }

    /**
     * @Route("/product/{id}/details/{slug}", name="product", requirements={"id" = "\d+"})
     */
    public function product(int $id, string $slug): Response
    {
        return $this->render('store/product.html.twig', [
            'id' => $id,
            'slug' => $slug,
        ]);
    }
}
