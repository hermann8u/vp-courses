<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/store", name="store_")
 */
class StoreController extends AbstractController
{
    /**
     * @Route("/products", name="products")
     */
    public function products()
    {
        return $this->render('store/products.html.twig');
    }

    /**
     * @Route("/product/{id}/details/{slug}", name="product", requirements={"id" = "\d+"})
     */
    public function product(int $id, string $slug)
    {
        return $this->render('store/product.html.twig', [
            'id' => $id,
            'slug' => $slug
        ]);
    }
}
