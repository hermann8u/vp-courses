<?php

namespace App\Controller;

use App\Entity\Contact;
use App\Form\ContactType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("", name="cms_")
 */
class CmsController extends AbstractController
{
    /**
     * @var \Swift_Mailer
     */
    private $mailer;

    /**
     * @var string
     */
    private $contactEmailAddress;

    public function __construct(\Swift_Mailer $mailer, string $contactEmailAddress)
    {
        $this->mailer = $mailer;
        $this->contactEmailAddress = $contactEmailAddress;
    }

    /**
     * @Route("/", name="homepage")
     */
    public function homepage()
    {
        return $this->render('cms/homepage.html.twig');
    }

    /**
     * @Route("/presentation", name="presentation")
     */
    public function presentation()
    {
        return $this->render('cms/presentation.html.twig');
    }

    /**
     * @Route("/contact", name="contact")
     */
    public function contact(Request $request, \Swift_Mailer $mailer)
    {
        $contact = new Contact();
        $form = $this->createForm(ContactType::class, $contact);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $message = (new \Swift_Message('Hello Email'))
                ->setFrom($contact->getEmail())
                ->setTo($this->contactEmailAddress)
                ->setBody(
                    $this->renderView('email/contact.html.twig', ['contact' => $contact]),
                    'text/html'
                );

            $mailer->send($message);

            $this->addFlash('success', 'Merci, votre message a été pris en compte !');

            return $this->redirectToRoute('cms_contact');
        }

        return $this->render('cms/contact.html.twig', [
            'form' => $form->createView()
        ]);
    }
}
