<?php

namespace App\DataFixtures;

use App\Entity\Store\Brand;
use App\Entity\Store\Color;
use App\Entity\Store\Image;
use App\Entity\Store\Product;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;

class AppFixtures extends Fixture
{
    const LOREM = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.';

    /**
     * @var ObjectManager
     */
    private $manager;

    public function load(ObjectManager $manager)
    {
        $this->manager = $manager;

        $this->loadImages();
        $this->loadBrands();
        $this->loadColors();
        $this->loadProducts();
    }

    private function loadImages()
    {
        for ($i = 1; $i < 15; $i++) {
            $image = (new Image())
                ->setUrl('shoe-'.$i.'.jpg')
                ->setAlt('Shoe '.$i);

            $this->manager->persist($image);
            $this->addReference('image'.$i, $image);
        }

        $this->manager->flush();
    }

    private function loadBrands()
    {
        $brandsName = [
            'Adidas',
            'Asics',
            'Nike',
            'Puma'
        ];

        foreach ($brandsName as $key => $brandName) {
            $brand = (new Brand())->setName($brandName);

            $this->manager->persist($brand);
            $this->addReference('brand'.$key, $brand);
        }

        $this->manager->flush();
    }

    private function loadColors()
    {
        $colorsNames = ['Jaune', 'Bleu', 'Rouge', 'Blanc', 'Noire', 'Vert'];

        foreach ($colorsNames as $key => $colorName) {
            $color = (new Color())->setName($colorName);

            $this->manager->persist($color);
            $this->addReference('color'.$key, $color);
        }

        $this->manager->flush();
    }

    private function loadProducts()
    {
        for ($i = 1; $i < 15; $i++) {
            $product = (new Product())
                ->setName('Produit '.$i)
                ->setDescription('Produit de description '.$i)
                ->setLongDescription(self::LOREM)
                ->setSlug('produit-'.$i)
                ->setImage($this->getReference('image'.$i))
                ->setBrand($this->getReference('brand'.random_int(0, 3)))
                ->setPrice(mt_rand(10, 100));

            for ($j = 0; $j < 6; $j++) {
                if ($this->randomBool()) {
                    $product->addColor($this->getReference('color'.$j));
                }
            }

            $this->manager->persist($product);
        }

        $this->manager->flush();
    }

    private function randomBool()
    {
        return (bool) random_int(0, 1);
    }

}
