<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/store", name="store_")
 */
class StoreController extends AbstractController
{
    /**
     * @Route("/product/{id}/details/{slug}", name="store", requirements={"id" = "\d+"})
     */
    public function product(Request $request, int $id, string $slug)
    {
        return $this->render('store/product.html.twig', [
            'id' => $id,
            'slug' => $slug,
            'ip' => $request->getClientIp(),
            'url' => $request->getUri()
        ]);
    }
}
