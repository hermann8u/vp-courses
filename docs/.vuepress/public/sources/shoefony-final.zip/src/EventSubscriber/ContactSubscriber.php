<?php

namespace App\EventSubscriber;

use App\Events;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\EventDispatcher\GenericEvent;
use Twig\Environment;

class ContactSubscriber implements EventSubscriberInterface
{
    /**
     * @var \Swift_Mailer
     */
    private $mailer;

    /**
     * @var Environment
     */
    private $twig;

    /**
     * @var string
     */
    private $contactEmailAddress;

    public function __construct(\Swift_Mailer $mailer, Environment $twig, string $contactEmailAddress)
    {
        $this->mailer = $mailer;
        $this->twig = $twig;
        $this->contactEmailAddress = $contactEmailAddress;
    }

    public static function getSubscribedEvents()
    {
        return [
            Events::ENTITY_CONTACT_CREATED => [
                ['sendEmail', 0]
            ]
        ];
    }

    public function sendEmail(GenericEvent $event)
    {
        $contact = $event->getSubject();
        $message = (new \Swift_Message('Hello Email'))
            ->setFrom($contact->getEmail())
            ->setTo($this->contactEmailAddress)
            ->setBody(
                $this->twig->render('email/contact.html.twig', ['contact' => $contact]),
                'text/html'
            );

        $this->mailer->send($message);
    }
}