<?php

namespace App\Controller;

use App\Entity\Store\Opinion;
use App\Form\OpinionType;
use App\Repository\Store\BrandRepository;
use App\Repository\Store\ProductRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/store", name="store_")
 */
class StoreController extends AbstractController
{
    /**
     * @var EntityManagerInterface
     */
    private $em;

    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * @var BrandRepository
     */
    private $brandRepository;

    public function __construct(EntityManagerInterface $em, ProductRepository $productRepository, BrandRepository $brandRepository)
    {
        $this->em = $em;
        $this->productRepository = $productRepository;
        $this->brandRepository = $brandRepository;
    }

    /**
     * @Route("/search", name="search")
     */
    public function search(Request $request)
    {
        $queryString = $request->query->get('q');
        $products = $this->productRepository->findSearch($queryString);

        return $this->render('store/products.html.twig', [
            'products' => $products,
            'brandId' => null,
            'brand' => null,
            'queryString' => $queryString
        ]);
    }

    /**
     * @Route("/products", name="products")
     * @Route("/products/brand/{brandId}", name="brand_products", requirements={"brandId" = "\d+"})
     */
    public function products(Request $request, int $brandId = null)
    {
        if ($brandId) {
            $brand = $this->brandRepository->find($brandId);
            if (!$brand) {
                throw $this->createNotFoundException();
            }

            $products = $this->productRepository->findByBrand($brand);
        } else {
            if ($request->attributes->get('_route') === 'store_brand_products') {
                return $this->redirectToRoute('store_products');
            }

            $products = $this->productRepository->findAllWithImage();
            $brand = null;
        }

        return $this->render('store/products.html.twig', [
            'products' => $products,
            'brandId' => $brandId,
            'brand' => $brand
        ]);
    }

    /**
     * @Route("/product/{id}/details/{slug}", name="product", requirements={"id" = "\d+"})
     */
    public function product(Request $request, int $id, string $slug)
    {
        $product = $this->productRepository->findOneWithDetails($id);

        if (!$product || $product->getSlug() !== $slug) {
            throw $this->createNotFoundException();
        }

        $opinion = (new Opinion())->setProduct($product);
        $form = $this->createForm(OpinionType::class, $opinion);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->em->persist($opinion);
            $this->em->flush();

            $this->addFlash('success', 'Merci, votre avis a été pris en compte !');

            return $this->redirectToRoute('store_product', [
                'id' => $id,
                'slug' => $slug
            ]);
        }

        return $this->render('store/product.html.twig', [
            'product' => $product,
            'form' => $form->createView()
        ]);
    }

    public function brandsList(int $currentBrandId = null)
    {
        return $this->render('store/_brands_list.html.twig', [
            'brands' => $this->brandRepository->findAll(),
            'currentBrandId' => $currentBrandId
        ]);
    }
}
