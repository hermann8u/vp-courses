<?php

namespace App\Controller;

use App\Entity\Contact;
use App\Events;
use App\Form\ContactType;
use App\Repository\Store\ProductRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\EventDispatcher\GenericEvent;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("", name="cms_")
 */
class CmsController extends AbstractController
{
    /**
     * @var EntityManagerInterface
     */
    private $em;

    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * @var EventDispatcherInterface
     */
    private $eventDispatcher;

    public function __construct(EntityManagerInterface $em, ProductRepository $productRepository, EventDispatcherInterface $eventDispatcher)
    {
        $this->em = $em;
        $this->productRepository = $productRepository;
        $this->eventDispatcher = $eventDispatcher;
    }

    /**
     * @Route("/", name="homepage")
     */
    public function homepage()
    {
        return $this->render('cms/homepage.html.twig', [
            'newProducts' => $this->productRepository->findNew(),
            'mostPopularProducts' => $this->productRepository->findMostPopular()
        ]);
    }

    /**
     * @Route("/presentation", name="presentation")
     */
    public function presentation()
    {
        return $this->render('cms/presentation.html.twig');
    }

    /**
     * @Route("/contact", name="contact")
     */
    public function contact(Request $request)
    {
        $contact = new Contact();
        $form = $this->createForm(ContactType::class, $contact);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->em->persist($contact);
            $this->em->flush();

            $this->eventDispatcher->dispatch(Events::ENTITY_CONTACT_CREATED, new GenericEvent($contact));

            $this->addFlash('success', 'Merci, votre message a été pris en compte !');

            return $this->redirectToRoute('cms_contact');
        }

        return $this->render('cms/contact.html.twig', [
            'form' => $form->createView()
        ]);
    }
}
