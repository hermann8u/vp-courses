<?php

namespace App;


final class Events
{
    const ENTITY_CONTACT_CREATED = 'entity.contact.created';
}