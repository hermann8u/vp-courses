<?php

namespace App\Repository\Store;

use App\Entity\Store\Brand;
use App\Entity\Store\Product;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * @method Product|null find($id, $lockMode = null, $lockVersion = null)
 * @method Product|null findOneBy(array $criteria, array $orderBy = null)
 * @method Product[]    findAll()
 * @method Product[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class ProductRepository extends ServiceEntityRepository
{
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, Product::class);
    }

    public function createQueryBuilderWithImage($alias, $indexBy = null)
    {
        return $this
            ->createQueryBuilder($alias, $indexBy)
            ->addSelect('i')
            ->leftJoin('p.image', 'i');
    }

    public function findAllWithImage()
    {
        return $this
            ->createQueryBuilderWithImage('p')
            ->getQuery()
            ->getResult();
    }

    public function findByBrand(Brand $brand)
    {
        return $this
            ->createQueryBuilderWithImage('p')
            ->where('p.brand = :brand')
            ->setParameter('brand', $brand)
            ->getQuery()
            ->getResult();
    }

    public function findNew()
    {
        return $this
            ->createQueryBuilderWithImage('p')
            ->setMaxResults(Product::MAX_NEW)
            ->orderBy('p.createdAt', 'DESC')
            ->getQuery()
            ->getResult();
    }

    public function findMostPopular()
    {
        return $this
            ->createQueryBuilderWithImage('p')
            ->leftJoin('p.opinions', 'o')
            ->orderBy('COUNT(o)', 'DESC')
            ->setMaxResults(Product::MAX_MOST_POPULAR)
            ->groupBy('p')
            ->getQuery()
            ->getResult();
    }

    public function findOneWithDetails(int $id)
    {
        return $this
            ->createQueryBuilderWithImage('p')
            ->addSelect('o')
            ->leftJoin('p.opinions', 'o')
            ->addSelect('c')
            ->leftJoin('p.colors', 'c')
            ->where('p.id = :id')
            ->orderBy('o.createdAt', 'DESC')
            ->setParameter('id', $id)
            ->getQuery()
            ->getOneOrNullResult();
    }
}
